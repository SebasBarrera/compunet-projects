package co.edu.icesi.ci.injectionexample1.repositories;

import co.edu.icesi.ci.injectionexample1.model.Course;

public interface CourseRepository {

	public Course getCourse (String id, String name);
}
