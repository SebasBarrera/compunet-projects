package co.edu.icesi.ci.injectionexample1.service;

public interface RegistrationService {

	public boolean enrolStudent(String studentId, String courseId, int semester, String name);
}
